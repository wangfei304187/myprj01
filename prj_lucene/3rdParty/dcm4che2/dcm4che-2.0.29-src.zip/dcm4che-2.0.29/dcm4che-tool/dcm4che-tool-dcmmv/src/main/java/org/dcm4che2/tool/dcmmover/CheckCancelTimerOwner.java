package org.dcm4che2.tool.dcmmover;

/**
 * @author gpotter (gcac96@gmail.com)
 * @version $Revision$
 */
public interface CheckCancelTimerOwner {

    public void timerFired();
}
