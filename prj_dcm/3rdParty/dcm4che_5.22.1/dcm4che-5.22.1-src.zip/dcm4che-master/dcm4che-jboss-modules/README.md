JBoss AS7 Module
================

* Build project with `mvn install`
* Unzip content of _target/dcm4che-jboss-modules-3.0.0-SNAPSHOT.zip_ into the jboss root directory, e.g.
```
unzip target/dcm4che-jboss-modules-3.0.0-SNAPSHOT.zip -d /jboss-as-7.1.1.Final/
```
