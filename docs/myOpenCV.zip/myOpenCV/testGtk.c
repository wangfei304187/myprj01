/*
gtk测试用例
 
https://blog.csdn.net/qinglongzhan/article/details/81942935
 
$ gcc -o testGtk testGtk.c `pkg-config --libs --cflags gtk+-2.0`

$ ./testGtk     若出现对话框表示成功！
*/

#include <gtk/gtk.h>  
  
int main(int argc, char *argv[])  
{  
    GtkWidget *windows;  
    gtk_init(&argc,&argv);  
 
    windows = gtk_window_new(GTK_WINDOW_TOPLEVEL);  
    gtk_widget_show(windows);  
 
    gtk_main();  

    return 0;  
} 
