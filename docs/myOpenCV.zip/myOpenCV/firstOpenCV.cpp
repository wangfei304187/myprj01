/*
 * https://blog.csdn.net/qinglongzhan/article/details/81942935
 * 
 * g++ -g -o firstOpenCV firstOpenCV.cpp `pkg-config --cflags --libs opencv`
*/

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
 
int main(int argc,char *argv[])
{
	cv::Mat image;
	image=cv::imread("lena.png");
	
	cv::namedWindow("lena.png");
	cv::imshow("lena.png",image);
 
	cv::waitKey();
	return 0;
}

