This directory contains material supporting chapter 6 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.

File:
	filters.cpp
correspond to Recipes:
Filtering Images using Low-pass Filters
Filtering Images using a Median Filter

Files:
	dderivatives.cpp
	laplacianZC.h
correspond to Recipes:
Applying Directional Filters to Detect Edges
Computing the Laplacian of an Image
