opencv-2-cookbook 中文版配套源代码
=====================
[第一版勘误整理](https://github.com/vinjn/opencv-2-cookbook-src/issues/62)
<br>
[#我想要OpenCV新书#活动说明（已结束）](https://github.com/vinjn/opencv-2-cookbook-src/issues/1) 及 [获奖者名单](https://github.com/vinjn/opencv-2-cookbook-src/issues?labels=%E8%8E%B7%E5%A5%96%E8%80%85&page=1&state=closed)

----


![](https://raw.github.com/vinjn/vinjn.github.io/master/images/opecv-cookbook-face.jpg)

