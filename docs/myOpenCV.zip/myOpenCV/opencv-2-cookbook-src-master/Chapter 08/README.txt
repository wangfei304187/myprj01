This directory contains material supporting chapter 8 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
by Robert Laganiere, Packt Publishing, 2011.

Files:
	harrisDetector.h
	interestPoints.cpp
correspond to Recipes:
Detecting Harris Corners
Detecting Fast Features
Detecting the Scale-Invariant SURF Features

File:
	blobs.cpp
correspond to Recipe:
Describing SURF Features