 1.  gtk测试用例
 
https://blog.csdn.net/qinglongzhan/article/details/81942935
 

$ gcc -o testGtk testGtk.c `pkg-config --libs --cflags gtk+-2.0`

$ ./testGtk     若出现对话框表示成功！



2. first openVC app

https://blog.csdn.net/qinglongzhan/article/details/81942935


g++ -g -o firstOpenCV firstOpenCV.cpp `pkg-config --cflags --libs opencv`



3. saltImage


g++ -g -o saltImage saltImage.cpp `pkg-config --cflags --libs opencv`